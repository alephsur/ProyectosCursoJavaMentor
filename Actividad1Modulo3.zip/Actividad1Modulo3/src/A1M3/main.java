package A1M3;




public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GestionAlumnos gestion = new GestionAlumnos();
		gestion.Dise�arPantalla();
		
	}

}
